# StudyPro

Aplicativo Android simples para organizar a revisão do Provão Paulista.

## Conteúdo
- Cronograma de 10 dias
- No máximo duas áreas de estudo por dia (alguns dias agrupam conteúdos relacionados)
- Checklist local de conteúdos na tela

## Gerar APK
O workflow do GitHub Actions pode compilar o projeto com Gradle 8.9 e JDK 17.
