package br.com.studypro

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val blue = Color.rgb(35, 94, 160)
    private val ink = Color.rgb(35, 43, 55)
    private val pale = Color.rgb(239, 245, 252)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(248, 250, 253))
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 32)
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(text("STUDYPRO", 14, blue, true))
        page.addView(text("Seu plano de estudos", 27, ink, true))
        page.addView(text("Provão Paulista • revisão organizada", 15, Color.DKGRAY, false))
        page.addView(space(18))
        page.addView(card("COMO USAR", "Estude no máximo duas matérias por dia. Marque cada conteúdo quando terminar e revise os pontos em que tiver mais dificuldade."))
        page.addView(space(12))

        val sections = listOf(
            "DIA 1 • LINGUAGENS" to listOf("Português: gêneros multimodais, tirinhas, ambiguidade e ironia", "Literatura: trovadorismo, cantigas de amigo, Barroco (Gregório de Matos) e Arcadismo (Bocage)", "Figuras de linguagem e figuras de sintaxe"),
            "DIA 2 • NATUREZA" to listOf("Biologia: ciclo do nitrogênio, ciclo do carbono e eutrofização", "Química: densidade, solubilidade, imiscibilidade e filtração", "Modelos atômicos de Rutherford e Bohr"),
            "DIA 3 • MATEMÁTICA" to listOf("Razão, proporção e porcentagem", "Aumentos e descontos sucessivos", "Função afim e função quadrática: vértice, máximo e mínimo", "Estatística: média, moda e mediana"),
            "DIA 4 • FÍSICA" to listOf("Velocidade média e gráficos posição × tempo", "Leis de Newton: ação e reação", "Energia mecânica, trabalho e Lei de Hooke"),
            "DIA 5 • HUMANAS" to listOf("Democracia ateniense: cidadania, características e limites", "Mercantilismo e sistema colonial", "Feudalismo, capitalismo e Revolução Industrial", "Cartografia, fusos horários e domínios morfoclimáticos"),
            "DIA 6 • FILOSOFIA E SOCIOLOGIA" to listOf("Mito e Logos; Método Socrático", "Contratualismo de Hobbes", "Precarização do trabalho e racismo ambiental"),
            "DIA 7 • INGLÊS" to listOf("Interpretação de notícias e cartoons", "Conectivos e falsos cognatos"),
            "DIA 8 • QUÍMICA E BIOLOGIA" to listOf("Estequiometria: reagente limitante e excesso", "Fisiologia humana: trocas gasosas nos alvéolos"),
            "DIA 9 • REVISÃO GERAL" to listOf("Revise fórmulas: velocidade média, porcentagem e equações do 1º e 2º grau", "Refaça exercícios que errou e releia seus resumos"),
            "DIA 10 • VÉSPERA" to listOf("Leitura leve dos resumos e fórmulas", "Separe documentos e materiais; descanse")
        )

        sections.forEach { (heading, topics) ->
            page.addView(text(heading, 17, blue, true))
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 10, 14, 10)
                setBackgroundColor(Color.WHITE)
            }
            topics.forEach { topic ->
                val check = CheckBox(this).apply {
                    text = topic
                    textSize = 14f
                    setTextColor(ink)
                    setPadding(0, 5, 0, 5)
                }
                box.addView(check)
            }
            page.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 })
        }
        page.addView(card("DICA", "Faça blocos de 25 a 40 minutos, com pequenas pausas. Se um assunto estiver difícil, anote a dúvida para revisar depois."))
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 4, 0, 5)
        }

    private fun space(height: Int) = TextView(this).apply { this.height = height }

    private fun card(title: String, body: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(pale)
        }
        box.addView(text(title, 13, blue, true))
        box.addView(text(body, 14, ink, false))
        return box
    }
}
