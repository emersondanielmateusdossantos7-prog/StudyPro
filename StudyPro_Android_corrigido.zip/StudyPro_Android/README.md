# StudyPro – Provão Paulista 2026

Aplicativo Android nativo em Kotlin + Jetpack Compose.

## Recursos
- Cronograma de 03/11 a 11/11/2026, com até duas matérias por dia.
- Conteúdos detalhados conforme as folhas de revisão enviadas.
- Checklist de conteúdos com salvamento local.
- Progresso geral.
- Cronômetro de estudos.
- Anotações salvas automaticamente.
- Funciona offline após instalado.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `StudyPro_Android` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale o Android SDK 35 e use o JDK 17.
5. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfira o APK para o celular Android e instale. O Android poderá pedir autorização para instalar apps dessa origem.

## Observações
- Este pacote contém o projeto-fonte Android Studio, não um APK já compilado.
- O cronograma foi organizado com base nas quatro folhas enviadas. Datas e conteúdos podem ser ajustados no arquivo `MainActivity.kt`.
- O progresso e as anotações ficam armazenados localmente no aparelho.

## Alternativa: gerar o APK pelo GitHub Actions (sem instalar Android Studio)
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta para ele.
2. Abra a aba **Actions** do repositório.
3. Se necessário, habilite os GitHub Actions e execute **Build StudyPro APK** em **Run workflow**.
4. Quando a execução terminar, abra a execução concluída e baixe o artefato **StudyPro-APK**.
5. Dentro do ZIP baixado estará `app-debug.apk`, pronto para transferir ao Android.

O GitHub exige uma conta e que você envie o projeto ao repositório. Não compartilhe senhas ou tokens com ninguém.
