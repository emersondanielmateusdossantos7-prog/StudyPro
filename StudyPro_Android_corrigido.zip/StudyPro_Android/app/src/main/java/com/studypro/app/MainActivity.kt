package com.studypro.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private data class StudyDay(val date: String, val weekday: String, val subjects: List<StudySubject>)
private data class StudySubject(val name: String, val topics: List<String>)

private val studyPlan = listOf(
    StudyDay("03/11", "Terça-feira", listOf(
        StudySubject("Português", listOf("Gêneros multimodais: tirinhas, ambiguidade, ironia e linguagem verbal/não verbal", "Trovadorismo: cantigas de amigo, paralelismo e refrão")),
        StudySubject("Biologia", listOf("Ciclo do nitrogênio: fixação e nitrificação", "Ciclo do carbono", "Eutrofização em ecossistemas aquáticos"))
    )),
    StudyDay("04/11", "Quarta-feira", listOf(
        StudySubject("Matemática", listOf("Razão e proporção", "Porcentagem", "Aumentos e descontos sucessivos", "Leitura de tabelas e gráficos")),
        StudySubject("Física", listOf("Velocidade média", "Gráficos velocidade × tempo e deslocamento pela área", "3ª Lei de Newton: ação e reação"))
    )),
    StudyDay("05/11", "Quinta-feira", listOf(
        StudySubject("Química", listOf("Densidade e solubilidade", "Imiscibilidade e filtração simples", "Modelos atômicos de Rutherford e Bohr")),
        StudySubject("História", listOf("Democracia ateniense: características e limites sociais da cidadania", "Mercantilismo e práticas do Sistema Colonial"))
    )),
    StudyDay("06/11", "Sexta-feira", listOf(
        StudySubject("Geografia", listOf("Escalas gráfica e numérica", "Fusos horários", "Domínios morfoclimáticos: Caatinga e Cerrado")),
        StudySubject("Filosofia e Sociologia", listOf("Transição do mito ao logos", "Método socrático", "Contratualismo de Hobbes", "Precarização do trabalho"))
    )),
    StudyDay("07/11", "Sábado", listOf(
        StudySubject("Inglês", listOf("Interpretação de notícias autênticas e charges", "Conectivos e falsos cognatos")),
        StudySubject("Português e Literatura", listOf("Barroco no Brasil: Gregório de Matos, vertentes lírica e satírica", "Arcadismo: Bocage", "Conectivos coesivos"))
    )),
    StudyDay("08/11", "Domingo", listOf(
        StudySubject("Matemática", listOf("Função afim: tarifas fixas e variáveis", "Função quadrática: vértice da parábola", "Ponto de máximo e mínimo", "Equações do 1º e 2º grau", "Regra de três e estatística: média, moda e mediana")),
        StudySubject("Física", listOf("Conservação da energia mecânica: potencial e cinética", "Trabalho da força peso", "Lei de Hooke"))
    )),
    StudyDay("09/11", "Segunda-feira", listOf(
        StudySubject("Biologia", listOf("Fisiologia humana", "Trocas gasosas no sistema respiratório")),
        StudySubject("Química", listOf("Estequiometria", "Reagente limitante e reagente em excesso"))
    )),
    StudyDay("10/11", "Terça-feira", listOf(
        StudySubject("História", listOf("Transição do Feudalismo ao Capitalismo", "Revolução Industrial e Ludismo")),
        StudySubject("Geografia", listOf("Racismo ambiental", "Globalização", "Revisão dos domínios morfoclimáticos"))
    )),
    StudyDay("11/11", "Quarta-feira", listOf(
        StudySubject("Filosofia e Sociologia", listOf("Método socrático", "Contratualismo", "Precarização do trabalho")),
        StudySubject("Inglês", listOf("Interpretação de textos e notícias", "Charges, conectivos e falsos cognatos"))
    ))
)

private val navy = Color(0xFF14243A)
private val blue = Color(0xFF3478F6)
private val pale = Color(0xFFF3F6FB)
private val green = Color(0xFF1D9B70)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyProApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyProApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("studypro", Context.MODE_PRIVATE) }
    var selectedTab by remember { mutableStateOf(0) }
    var selectedDay by remember { mutableIntStateOf(0) }
    var checked by remember { mutableStateOf(prefs.getStringSet("checked", emptySet())?.toMutableSet() ?: mutableSetOf()) }
    var notes by remember { mutableStateOf(prefs.getString("notes", "") ?: "") }
    var seconds by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }

    LaunchedEffect(running) {
        while (running) {
            delay(1000)
            seconds++
        }
    }

    val totalTasks = studyPlan.sumOf { day -> day.subjects.sumOf { it.topics.size } }
    val progress = if (totalTasks == 0) 0f else checked.size.toFloat() / totalTasks
    val percent = (progress * 100).toInt()

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = blue,
            secondary = green,
            background = pale,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("StudyPro", fontWeight = FontWeight.Bold, color = navy, fontSize = 22.sp)
                            Text("PROVÃO PAULISTA • 2026", fontSize = 10.sp, color = Color.Gray, letterSpacing = 1.sp)
                        }
                    },
                    actions = {
                        Box(Modifier.padding(end = 16.dp).size(38.dp).background(Color(0xFFE5EDFF), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.School, contentDescription = null, tint = blue)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = pale)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Início") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Cronograma") })
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.EditNote, null) }, label = { Text("Anotações") })
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(
                    padding, percent, checked.size, totalTasks, selectedDay,
                    onOpenPlan = { selectedTab = 1 },
                    onToday = { selectedDay = 0; selectedTab = 1 },
                    seconds = seconds, running = running,
                    onToggleTimer = { running = !running },
                    onResetTimer = { running = false; seconds = 0 }
                )
                1 -> PlanScreen(padding, selectedDay, { selectedDay = it }, checked,
                    onToggle = { key ->
                        val next = checked.toMutableSet()
                        if (!next.add(key)) next.remove(key)
                        checked = next
                        prefs.edit().putStringSet("checked", next).apply()
                    })
                else -> NotesScreen(padding, notes, onChange = {
                    notes = it
                    prefs.edit().putString("notes", it).apply()
                })
            }
        }
    }
}

@Composable
private fun HomeScreen(
    padding: PaddingValues, percent: Int, done: Int, total: Int, selectedDay: Int,
    onOpenPlan: () -> Unit, onToday: () -> Unit, seconds: Int, running: Boolean,
    onToggleTimer: () -> Unit, onResetTimer: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 22.dp)) {
        item {
            Spacer(Modifier.height(4.dp))
            Text("Sua preparação começa aqui.", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = navy)
            Text("Provas: 12 e 13 de novembro", color = Color.Gray, fontSize = 14.sp)
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = navy)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("SEU PROGRESSO", color = Color(0xFFB9C8DC), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("$percent%", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                            Text("$done de $total conteúdos concluídos", color = Color(0xFFD3DDED), fontSize = 13.sp)
                        }
                        Box(Modifier.size(64.dp).background(Color(0xFF263D5C), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.TrendingUp, null, tint = Color(0xFF7DB0FF), modifier = Modifier.size(32.dp))
                        }
                    }
                    LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Color(0xFF75A8FF), trackColor = Color(0xFF334B6B))
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, null, tint = blue)
                        Spacer(Modifier.width(8.dp))
                        Text("Cronômetro de estudos", fontWeight = FontWeight.SemiBold, color = navy)
                    }
                    Text(String.format("%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = navy)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onToggleTimer, modifier = Modifier.weight(1f)) {
                            Icon(if (running) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (running) "Pausar" else "Começar")
                        }
                        OutlinedButton(onClick = onResetTimer) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(4.dp)); Text("Zerar") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().clickable { onToday() }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("PRÓXIMO PASSO", color = blue, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text("Abrir meu cronograma", fontWeight = FontWeight.Bold, color = navy, fontSize = 17.sp)
                        Text("Veja as duas matérias do dia e marque seus conteúdos.", color = Color.Gray, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.ArrowForward, null, tint = blue)
                }
            }
        }
        item {
            OutlinedButton(onClick = onOpenPlan, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text("Ver cronograma completo")
            }
        }
    }
}

@Composable
private fun PlanScreen(
    padding: PaddingValues, selectedDay: Int, onSelectDay: (Int) -> Unit, checked: Set<String>,
    onToggle: (String) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Text("Cronograma de estudos", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = navy)
            Text("De 3 a 11 de novembro • até 2 matérias por dia", color = Color.Gray, fontSize = 13.sp)
        }
        item {
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(studyPlan) { index, day ->
                    val active = selectedDay == index
                    Surface(
                        modifier = Modifier.clickable { onSelectDay(index) },
                        shape = RoundedCornerShape(14.dp),
                        color = if (active) blue else Color.White,
                        shadowElevation = if (active) 2.dp else 0.dp
                    ) {
                        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(day.date, color = if (active) Color.White else navy, fontWeight = FontWeight.Bold)
                            Text(day.weekday.take(3), color = if (active) Color.White.copy(alpha = .8f) else Color.Gray, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        item {
            val day = studyPlan[selectedDay]
            Text("${day.weekday}, ${day.date}", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = navy)
            Text("Marque cada conteúdo depois de estudar.", color = Color.Gray, fontSize = 12.sp)
        }
        itemsIndexed(studyPlan[selectedDay].subjects) { subjectIndex, subject ->
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).background(Color(0xFFEAF0FF), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MenuBook, null, tint = blue)
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(subject.name, fontWeight = FontWeight.Bold, color = navy, fontSize = 17.sp)
                    }
                    subject.topics.forEachIndexed { topicIndex, topic ->
                        val key = "$selectedDay-$subjectIndex-$topicIndex"
                        Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth().clickable { onToggle(key) }) {
                            Checkbox(checked = checked.contains(key), onCheckedChange = { onToggle(key) })
                            Text(topic, modifier = Modifier.weight(1f).padding(top = 11.dp), color = if (checked.contains(key)) Color.Gray else Color(0xFF344256), fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotesScreen(padding: PaddingValues, notes: String, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Minhas anotações", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = navy)
        Text("Registre dúvidas, fórmulas e assuntos que precisa revisar. O texto fica salvo neste aparelho.", color = Color.Gray, fontSize = 13.sp)
        OutlinedTextField(
            value = notes,
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth().weight(1f),
            placeholder = { Text("Escreva suas anotações aqui...") },
            shape = RoundedCornerShape(16.dp)
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CloudDone, null, tint = green)
            Spacer(Modifier.width(6.dp))
            Text("Salvo automaticamente no celular", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
